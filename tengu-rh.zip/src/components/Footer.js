
import React from "react";

function Footer() {
  return (
    <footer>
      <p>&copy; 2025 TËNGU RH. Tous droits réservés.</p>
    </footer>
  );
}

export default Footer;
